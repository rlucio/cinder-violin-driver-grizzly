#!/usr/bin/env python

# =============================================================================
# Copyright 2012-2013 Violin Memory, Inc.. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY VIOLIN MEMORY, INC  ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
# EVENT SHALL VIOLIN MEMORY, INC  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation are
# those of the authors and should not be interpreted as representing official
# policies, either expressed or implied, of Violin Memory, Inc.
# =============================================================================

from vxg.core.node import XGNode
from vxg.core.error import *
from vxg.core.request import XGQuery, XGAction, XGEvent, XGSet

"""
Here's an example of how to extend the functionality in this module:

class IGroupManager_1(IGroupManager):
    def __init__(self, basic):
        super(IGroupManager_1, self).__init__(basic)

    def new_function(self, *args):
        pass

"""

class IGroupManager(object):
    def __init__(self, basic):
        self._basic = basic

    def create_igroup(self, igroup):
        """
        Create an igroup.

        Arguments:
            igroup -- string

        Returns:
            Action result as a dict.

        """
        return self._igroup_create(igroup, False)

    def delete_igroup(self, igroup):
        """
        Deletes an igroup.

        Arguments:
            igroup -- string

        Returns:
            Action result as a dict.

        """
        return self._igroup_create(igroup, True)

    def add_initiators(self, igroup, initiators):
        """
        Add initiators to an igroup.

        Arguments:
            igroup     -- string
            initiators -- string (string or list)

        Returns:
            Action result as a dict.

        """
        return self._igroup_modify(igroup, initiators, False)

    def delete_initiators(self, igroup, initiators):
        """
        Delete initiators to an igroup.

        Arguments:
            igroup     -- string
            initiators -- string (string or list)

        Returns:
            Action result as a dict.

        """
        return self._igroup_modify(igroup, initiators, True)

    # Begin internal functions

    def _igroup_create(self, igroup, delete):
        """
        Internal work function for:
            create_igroup
            delete_igroup

        """

        nodes = []
        nodes.append(XGNode('igroup', 'string', igroup))
        nodes.append(XGNode('delete', 'bool', delete))
        return self._basic.perform_action('/vshare/actions' +
                                          '/igroup/create', nodes)

    def _igroup_modify(self, igroup, initiators, delete):
        """
        Internal work function for:
            add_initiators
            delete_initiators

        """
        nodes = []
        nodes.append(XGNode('igroup', 'string', igroup))
        nodes.extend(XGNode.as_node_list('initiators/{0}', 'string',
                                         initiators))
        nodes.append(XGNode('delete', 'bool', delete))

        return self._basic.perform_action('/vshare/actions' +
                                          '/igroup/modify', nodes)

class IGroupManager_1(IGroupManager):
    def __init__(self, basic):
        super(IGroupManager_1, self).__init__(basic)

    def rename_igroup(self, old_igroup, new_igroup):
        """
        Renames an igroup.

        Arguments:
            old_igroup -- string
            new_igroup -- string

        Returns:
            Action result as a dict.

        """
        nodes = []
        nodes.append(XGNode('old_igroup', 'string', old_igroup))
        nodes.append(XGNode('new_igroup', 'string', new_igroup))

        return self._basic.perform_action('/vshare/actions' +
                                          '/igroup/rename', nodes)



